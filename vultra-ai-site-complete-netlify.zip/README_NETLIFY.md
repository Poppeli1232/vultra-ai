# Deploying to Netlify

1. Push this folder to GitHub (root must contain `index.html`).
2. In Netlify: **Add new site → Import an existing project → GitHub → choose the repo**.
3. Build settings:
   - Build command: **(leave empty)** (static site)
   - Publish directory: **/** (root)
4. Click **Deploy site**.
5. URL should be: `https://<your-site-name>.netlify.app`

## If the link doesn't work

- **404 or "Not Found":** In Site settings → Build & deploy → check that **Publish directory** is `/` (root) and deploy succeeded.
- **Blank page / broken images:** Filenames are **case-sensitive**. Ensure links match exactly: `assets/frog.png` (not `Frog.png`).  
- **Subfolder problem:** If you placed files inside a folder (e.g., `/vultra-ai-site-complete/`), set **Publish directory** to that folder.
- **Cached DNS:** Wait 1–2 minutes and hard-refresh (Ctrl+F5).
- **Custom domain:** Verify domain & DNS in **Domain management** and issue a certificate in **HTTPS**.
- **Calendly blocked by extensions:** Disable strict ad blockers for the site.
- **Forms:** Netlify Forms require a successful build with the form in the HTML. Check **Forms** tab after deploy.
