// Mobile nav toggle
const toggle = document.querySelector('.nav-toggle');
const nav = document.querySelector('.main-nav');
toggle?.addEventListener('click', ()=>{
  const open = nav.style.display === 'flex';
  nav.style.display = open ? 'none' : 'flex';
  toggle.setAttribute('aria-expanded', String(!open));
});

// Smooth scroll for same-page anchors
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const href = a.getAttribute('href');
    if(href && href.length > 1 && document.querySelector(href)){
      e.preventDefault();
      document.querySelector(href).scrollIntoView({behavior:'smooth'});
      if(window.innerWidth < 640) nav.style.display='none';
    }
  });
});

// IntersectionObserver reveal
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if(entry.isIntersecting){
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, {threshold: 0.2});

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

// Contact form fallback (mailto if not using Netlify)
const form = document.getElementById('contactForm');
if(form){
  form.addEventListener('submit', function(e){
    // If hosted on Netlify, their JS intercepts; otherwise do a mailto fallback
    if(!location.hostname.includes('netlify.app')){
      e.preventDefault();
      const name = encodeURIComponent(form.name.value);
      const email = encodeURIComponent(form.email.value);
      const msg = encodeURIComponent(form.message.value);
      const body = `Name: ${name}%0D%0AEmail: ${email}%0D%0A%0D%0A${msg}`;
      window.location.href = `mailto:luottoapurit@gmail.com?subject=Vultra%20AI%20Contact&body=${body}`;
      const s = document.getElementById('formStatus');
      if(s){ s.textContent = 'Opening your email client…'; }
    }
  });
}
